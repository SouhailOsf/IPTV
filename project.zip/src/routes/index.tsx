import { createFileRoute } from "@tanstack/react-router";
import heroTvs from "@/assets/hero-tvs.jpg";
import sportBanner from "@/assets/sport-banner.jpg";
import vodCollage from "@/assets/vod-collage.jpg";
import { Check, Tv, Shield, Headphones, Film, Wifi, Monitor, Snowflake, Tag } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "IPTV Anbieter HD – Bestes IPTV Abonnement für endlose Unterhaltung" },
      { name: "description", content: "Bester IPTV Anbieter: 22.000+ Live-TV-Sender und 120.000+ Filme & Serien in 4K. Funktioniert auf jedem Gerät. Sofortige Aktivierung." },
      { property: "og:title", content: "IPTV Anbieter HD – Bestes IPTV Abonnement" },
      { property: "og:description", content: "22.000+ Live-Sender, 120.000+ Filme & Serien, 4K Qualität, sofortige Aktivierung." },
    ],
  }),
  component: Index,
});

const plans = [
  { months: "3 Monate", price: "€19.99" },
  { months: "6 Monate", price: "€29.99" },
  { months: "12 Monate", price: "€49.99", popular: true },
  { months: "24 Monate", price: "€79.99" },
];

const planFeatures = [
  "+22.000 Live TV Sender",
  "+120.000 Filme & Serien",
  "Anti-Freeze Technology",
  "4K, UHD, FHD, HD Qualität",
  "Funktioniert auf jedem Gerät",
  "Sofortige Aktivierung",
  "TV Programmführer (EPG)",
  "Pay Per View (PPV)",
  "24/7 Support",
];

const features = [
  { icon: Snowflake, title: "Anti-Freeze", text: "Streaming ohne Einfrieren oder Pufferung dank unserer frostfreien IPTV-Server." },
  { icon: Tag, title: "Niedrige Preise", text: "Top-Preise mit fortschrittlichen Funktionen, die Sie nirgendwo sonst bekommen." },
  { icon: Headphones, title: "Online Support", text: "Unser Expertenteam antwortet innerhalb von zehn Minuten – rund um die Uhr." },
  { icon: Film, title: "Neueste VODs & Serien", text: "Neue Filme und Serien werden vor allen anderen aktualisiert." },
  { icon: Shield, title: "Erweiterte Sicherheit", text: "Beste IPTV-Server mit fortschrittlichem Sicherheitssystem." },
  { icon: Monitor, title: "IPTV Multiroom", text: "Nutzen Sie Ihren IPTV-Server auf mehreren Geräten gleichzeitig." },
  { icon: Tv, title: "Video On Demand", text: "Über 160.000 Sender, Filme & Serien mit Catch-Up und EPG." },
  { icon: Wifi, title: "Kompatibilität", text: "Android, Smart TV, MAG Box, Firestick, iOS, Windows und macOS." },
];

const stats = [
  { value: "5K+", label: "Zufriedene Kunden" },
  { value: "4K+", label: "Aktive Leitungen" },
  { value: "51+", label: "Länder weltweit" },
  { value: "8+", label: "Jahre Erfahrung" },
];

const faqs = [
  { q: "Was ist IPTV?", a: "IPTV (Internet Protocol Television) ermöglicht das Streaming von TV-Sendern, Filmen und Serien über das Internet auf jedes Gerät Ihrer Wahl." },
  { q: "Auf welchen Geräten funktioniert es?", a: "Unser Service läuft auf Smart TVs, Android, iOS, MAG Box, Firestick, Windows und macOS." },
  { q: "Wie schnell wird mein Abo aktiviert?", a: "Sofort nach Zahlungseingang erhalten Sie Ihre Zugangsdaten – meist innerhalb weniger Minuten." },
  { q: "Gibt es eine kostenlose Testversion?", a: "Ja, kontaktieren Sie uns über WhatsApp und erhalten Sie Ihre kostenlose Demo." },
  { q: "Welche Internetgeschwindigkeit benötige ich?", a: "Wir empfehlen mindestens 10 Mbit/s für HD und 25 Mbit/s für 4K-Streaming." },
];

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <header className="sticky top-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-lg">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <a href="#" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/15 text-primary">
              <Tv className="h-5 w-5" />
            </div>
            <span className="font-bold tracking-tight">
              IPTV <span className="text-primary">ANBIETER</span> HD
            </span>
          </a>
          <nav className="hidden gap-8 text-sm md:flex">
            <a href="#home" className="text-primary">Home</a>
            <a href="#pricing" className="text-muted-foreground hover:text-foreground">Abonnement</a>
            <a href="#features" className="text-muted-foreground hover:text-foreground">Kanalliste</a>
            <a href="#contact" className="text-muted-foreground hover:text-foreground">Kontakt</a>
            <a href="#faq" className="text-muted-foreground hover:text-foreground">FAQ</a>
          </nav>
          <a
            href="#pricing"
            className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:opacity-90"
          >
            JETZT STARTEN
          </a>
        </div>
      </header>

      {/* Hero */}
      <section
        id="home"
        className="relative overflow-hidden"
        style={{ backgroundImage: "var(--gradient-hero)" }}
      >
        <div className="container mx-auto px-4 pb-16 pt-20 text-center">
          <h1 className="mx-auto max-w-4xl text-4xl font-bold leading-tight md:text-6xl">
            IPTV ANBIETER: Bestes IPTV Abonnement für endlose Unterhaltung
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-muted-foreground md:text-lg">
            Genießen Sie den besten IPTV-Service für jedes Gerät, weltweit, zu erschwinglichen Preisen.
            Zugang zu 22.000+ Live-Sendern und 120.000+ Filmen & Serien.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <a
              href="#pricing"
              className="rounded-full bg-primary px-7 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:opacity-90"
            >
              KOSTENLOSE DEMO HOLEN
            </a>
            <a
              href="#pricing"
              className="rounded-full border border-primary/60 px-7 py-3 font-semibold text-primary transition hover:bg-primary/10"
            >
              ABONNEMENT WÄHLEN
            </a>
          </div>
          <div className="relative mx-auto mt-16 max-w-4xl">
            <div className="absolute inset-0 rounded-3xl bg-primary/20 blur-3xl" />
            <img
              src={heroTvs}
              alt="IPTV auf mehreren Geräten"
              width={1280}
              height={1024}
              className="relative w-full rounded-2xl"
            />
          </div>
        </div>
      </section>

      {/* Sport */}
      <section className="container mx-auto grid items-center gap-10 px-4 py-20 md:grid-cols-2">
        <img src={sportBanner} alt="Live Sport" width={1280} height={800} loading="lazy" className="rounded-2xl" />
        <div>
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">Live Sport</p>
          <h2 className="mt-3 text-3xl font-bold md:text-4xl">
            Auf der Suche nach dem ultimativen Ort für Live Sport?
          </h2>
          <p className="mt-4 text-muted-foreground">
            Streamen Sie Live-Spiele der Premier League, La Liga, Serie A, Bundesliga sowie NCAA, NBA, NHL und NFL – zu Hause oder unterwegs.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href="#pricing" className="rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:opacity-90">
              JETZT DEMO HOLEN
            </a>
            <a href="#pricing" className="rounded-full border border-primary/60 px-6 py-3 text-sm font-semibold text-primary hover:bg-primary/10">
              ABONNEMENT
            </a>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="container mx-auto px-4 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">Preise</p>
          <h2 className="mt-3 text-3xl font-bold md:text-4xl">Wählen Sie Ihr Abonnement</h2>
          <p className="mt-4 text-muted-foreground">
            Pakete für jedes Budget – alle Funktionen inklusive.
          </p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {plans.map((p) => (
            <div
              key={p.months}
              className={`relative rounded-2xl border bg-card p-6 transition hover:-translate-y-1 ${
                p.popular ? "border-primary shadow-[var(--shadow-glow)]" : "border-border"
              }`}
            >
              {p.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">
                  BELIEBT
                </span>
              )}
              <p className="text-sm text-muted-foreground">IPTV ANBIETER</p>
              <h3 className="mt-1 text-xl font-bold">{p.months} Abo</h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-extrabold text-primary">{p.price}</span>
                <span className="text-sm text-muted-foreground">/einmal</span>
              </div>
              <ul className="mt-6 space-y-2 text-sm">
                {planFeatures.map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <a
                href="#contact"
                className="mt-6 block rounded-full bg-primary py-2.5 text-center text-sm font-semibold text-primary-foreground hover:opacity-90"
              >
                Jetzt kaufen
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Support */}
      <section id="contact" className="border-y border-border/50 bg-card/40">
        <div className="container mx-auto flex flex-col items-center gap-4 px-4 py-12 text-center">
          <h2 className="text-2xl font-bold md:text-3xl">Brauchen Sie Unterstützung?</h2>
          <p className="max-w-xl text-muted-foreground">
            Unser Support ist 24/7 verfügbar, um Ihre Fragen zu beantworten und Sie bei jedem Anliegen zu unterstützen.
          </p>
          <a href="#" className="rounded-full bg-primary px-7 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-glow)] hover:opacity-90">
            KONTAKTIEREN SIE UNS
          </a>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="container mx-auto px-4 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">Warum uns wählen?</p>
          <h2 className="mt-3 text-3xl font-bold md:text-4xl">
            Unser IPTV-Service ist der beste am Markt
          </h2>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="rounded-2xl border border-border bg-card p-6 transition hover:border-primary/60">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15 text-primary">
                <f.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* VOD */}
      <section className="container mx-auto grid items-center gap-10 px-4 py-20 md:grid-cols-2">
        <div>
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">Unsere Dienstleistungen</p>
          <h2 className="mt-3 text-3xl font-bold md:text-4xl">
            Schauen Sie was Sie wollen – wann und wo Sie wollen
          </h2>
          <p className="mt-4 text-muted-foreground">
            Lokale und internationale Sender, ein riesiger VOD-Katalog und faire Preise – alles auf einer Plattform.
          </p>
          <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
            {["Action 1.300+", "Comedy 700+", "Thriller 500+", "Drama 1.500+", "Horror 750+", "Fantasy 800+"].map((g) => (
              <div key={g} className="rounded-lg border border-border bg-card px-4 py-2">{g}</div>
            ))}
          </div>
          <a href="#pricing" className="mt-6 inline-block rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:opacity-90">
            ABONNEMENT WÄHLEN
          </a>
        </div>
        <img src={vodCollage} alt="Filme und Serien" width={1280} height={800} loading="lazy" className="rounded-2xl" />
      </section>

      {/* Stats */}
      <section className="border-y border-border/50 bg-card/40">
        <div className="container mx-auto grid grid-cols-2 gap-6 px-4 py-12 md:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="text-center">
              <div className="text-4xl font-extrabold text-primary md:text-5xl">{s.value}</div>
              <div className="mt-1 text-sm text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="container mx-auto max-w-3xl px-4 py-20">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">FAQ</p>
          <h2 className="mt-3 text-3xl font-bold md:text-4xl">Häufig gestellte Fragen</h2>
        </div>
        <div className="mt-10 space-y-3">
          {faqs.map((f) => (
            <details key={f.q} className="group rounded-xl border border-border bg-card p-5">
              <summary className="flex cursor-pointer items-center justify-between font-semibold">
                {f.q}
                <span className="text-primary transition group-open:rotate-45">+</span>
              </summary>
              <p className="mt-3 text-sm text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-card/40">
        <div className="container mx-auto flex flex-col items-center justify-between gap-4 px-4 py-8 text-sm text-muted-foreground md:flex-row">
          <div className="flex items-center gap-2">
            <Tv className="h-4 w-4 text-primary" />
            <span>IPTV ANBIETER HD © {new Date().getFullYear()}</span>
          </div>
          <div className="flex gap-6">
            <a href="#pricing" className="hover:text-foreground">Abonnement</a>
            <a href="#faq" className="hover:text-foreground">FAQ</a>
            <a href="#contact" className="hover:text-foreground">Kontakt</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
